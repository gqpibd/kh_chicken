package client.dao;

import java.util.ArrayList;
import java.util.List;

import dto.ReviewDto;



public class ReviewDao {
	
	List<ReviewDto> rList = new ArrayList<ReviewDto>();
	
	public ReviewDao() {
	}
	
	
	public void insert() {
		
	}
	
	public void select() {
		
	}
	
	public void update() {
		
	}
	
	public void delete() {
		
	}

}
