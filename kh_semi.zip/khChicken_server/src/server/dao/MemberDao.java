package server.dao;

public class MemberDao {
	
	public MemberDao() {
	}
	
	public void insert() {
		
	}
	
	public void select() {
		
	}
	
	public void update() {
		
	}
	
	public void delete() {
		
	}

}
