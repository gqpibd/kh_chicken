package server.dao;

public class OrderDao {
	
	public OrderDao() {
	}
	
	
	public void insert() {
		
	}
	
	public void select() {
		
	}
	
	public void update() {
		
	}
	
	public void delete() {
		
	}

}
