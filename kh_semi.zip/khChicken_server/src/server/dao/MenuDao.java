package server.dao;

public class MenuDao {
	
	public MenuDao() {
	}

	
	public void insert() {
		
	}
	
	public void select() {
		
	}
	
	public void update() {
		
	}
	
	public void delete() {
		
	}

}
