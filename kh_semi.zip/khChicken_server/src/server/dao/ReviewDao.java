package server.dao;

public class ReviewDao {
	
	public ReviewDao() {
	}
	
	
	public void insert() {
		
	}
	
	public void select() {
		
	}
	
	public void update() {
		
	}
	
	public void delete() {
		
	}

}
